from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_stub_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_export_attribute = resolve('export_attribute')
    l_0_interface = resolve('interface')
    pass
    yield 'class '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'StubDispatch {\n public:\n  static bool Accept('
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '* impl, mojo::Message* message);\n  static bool AcceptWithResponder(\n      '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '* impl,\n      mojo::Message* message,\n      std::unique_ptr<mojo::MessageReceiverWithStatus> responder);\n};\n\ntemplate <typename ImplRefTraits =\n              mojo::RawPtrImplRefTraits<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '>>\nclass '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub\n    : public mojo::MessageReceiverWithResponderStatus {\n public:\n  using ImplPointerType = typename ImplRefTraits::PointerType;\n\n  '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub() = default;\n  ~'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub() override = default;\n\n  void set_sink(ImplPointerType sink) { sink_ = std::move(sink); }\n  ImplPointerType& sink() { return sink_; }\n\n  bool Accept(mojo::Message* message) override {\n    if (ImplRefTraits::IsNull(sink_))\n      return false;\n    return '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'StubDispatch::Accept(\n        ImplRefTraits::GetRawPointer(&sink_), message);\n  }\n\n  bool AcceptWithResponder(\n      mojo::Message* message,\n      std::unique_ptr<mojo::MessageReceiverWithStatus> responder) override {\n    if (ImplRefTraits::IsNull(sink_))\n      return false;\n    return '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'StubDispatch::AcceptWithResponder(\n        ImplRefTraits::GetRawPointer(&sink_), message, std::move(responder));\n  }\n\n private:\n  ImplPointerType sink_;\n};'

blocks = {}
debug_info = '1=14&3=18&5=20&11=22&12=24&17=26&18=28&26=30&35=32'